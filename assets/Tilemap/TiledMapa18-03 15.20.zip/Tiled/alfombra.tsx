<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="alfombra" tilewidth="12" tileheight="12" tilecount="3072" columns="64">
 <image source="alfombra.jpeg" width="768" height="576"/>
</tileset>
