<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="escalera" tilewidth="12" tileheight="12" tilecount="2048" columns="32">
 <image source="escalera.jpeg" width="384" height="768"/>
 <tile id="1024">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="12"/>
  </objectgroup>
 </tile>
</tileset>
