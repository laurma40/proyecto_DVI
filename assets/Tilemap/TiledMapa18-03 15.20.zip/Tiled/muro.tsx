<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="muro" tilewidth="12" tileheight="12" tilecount="3840" columns="64">
 <image source="muro.jpeg" width="768" height="720"/>
</tileset>
