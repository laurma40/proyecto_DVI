<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="puertas" tilewidth="12" tileheight="12" tilecount="55" columns="11">
 <image source="puertas.png" width="132" height="71"/>
 <tile id="44">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="12"/>
   <object id="2" x="0" y="0" width="12" height="12"/>
  </objectgroup>
 </tile>
 <tile id="45">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="12"/>
  </objectgroup>
 </tile>
 <tile id="46">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="12"/>
  </objectgroup>
 </tile>
 <tile id="47">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="12"/>
  </objectgroup>
 </tile>
 <tile id="48">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="12"/>
  </objectgroup>
 </tile>
 <tile id="49">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="12"/>
  </objectgroup>
 </tile>
 <tile id="51">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="12"/>
   <object id="2" x="0" y="0" width="12" height="12"/>
   <object id="3" x="0" y="0" width="12" height="12"/>
   <object id="4" x="0" y="0" width="12" height="12"/>
  </objectgroup>
 </tile>
 <tile id="52">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="12"/>
  </objectgroup>
 </tile>
 <tile id="53">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="12" height="12"/>
  </objectgroup>
 </tile>
 <tile id="54">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="11" height="12"/>
   <object id="2" x="0" y="0" width="11.9091" height="12"/>
   <object id="3" x="0" y="0" width="11" height="12"/>
  </objectgroup>
 </tile>
</tileset>
