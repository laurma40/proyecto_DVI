<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="recursosSalon" tilewidth="12" tileheight="12" tilecount="4096" columns="64">
 <image source="recursosSalon.png" width="768" height="768"/>
</tileset>
